import {Environment} from '../app/help/interfaces';

export const environment: Environment = {
  production: true,
  apiKeyFb: 'AIzaSyD5h4id7fR0qcC1U_dAlziDXPC_mdqcBqU',
  fbDbUrl: 'https://weather-cards-657ed-default-rtdb.firebaseio.com/',
  apiKey: '0ecc34d6d329fb1c62bcf0bf7778ebb1'
};